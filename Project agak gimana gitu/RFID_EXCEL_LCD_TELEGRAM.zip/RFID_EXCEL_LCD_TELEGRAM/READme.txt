//Buat jaringan hotspotnya begini yaa.... SSID:absen PASS:absenrfid


#include <CTBot.h>
#include <SoftwareSerial.h>

// Konfigurasi Telegram Bot
#define BOT_TOKEN "7759317747:AAE8Yh2A2D8MaFgA5n2QsW1Cifldo1JJMhs"
#define CHAT_ID 6808719172  

// Konfigurasi SoftwareSerial
SoftwareSerial ArduinoSerial(D5, D6); // RX, TX

// Inisialisasi objek Telegram
CTBot myBot;

void setup() {
  // Inisialisasi Serial Debug
  Serial.begin(9600);
  
  // Inisialisasi Serial dengan Arduino
  ArduinoSerial.begin(9600);

  // Koneksi WiFi
  myBot.wifiConnect("absen", "absenrfid");

  // Set Telegram Token
  myBot.setTelegramToken(BOT_TOKEN);

  // Cek Koneksi Bot
  if (myBot.testConnection()) {
    Serial.println("Telegram Bot Terhubung!");
  } else {
    Serial.println("Koneksi Telegram Gagal!");
  }
}

void loop() {
  // Cek apakah ada data dari Arduino
  if (ArduinoSerial.available()) {
    // Baca data serial
    String pesanDariArduino = ArduinoSerial.readStringUntil('\n');
    pesanDariArduino.trim();

    // Parsing pesan (misalnya "NAMA,STATUS")
    int komaMIndex = pesanDariArduino.indexOf(',');
    String nama = pesanDariArduino.substring(0, komaMIndex);
    String status = pesanDariArduino.substring(komaMIndex + 1);

    // Siapkan pesan Telegram
    String pesanTelegram;
    if (status == "BERHASIL") {
      pesanTelegram = "✅ Absensi Berhasil\n";
      pesanTelegram += "Nama: " + nama + "\n";
    } else {
      pesanTelegram = "🚨 Kartu Tidak Dikenal\n";
      pesanTelegram += "Nama/UID: " + nama + "\n";
      pesanTelegram += "Status: HUBUNGI ADMIN";
    }

    // Kirim pesan ke Telegram
    myBot.sendMessage(CHAT_ID, pesanTelegram);

    // Debug
    Serial.println("Pesan dikirim ke Telegram: " + pesanTelegram);
  }
}

// Fungsi sederhana untuk waktu (nanti bisa diganti)
String getCurrentTime() {
  return "08:00 WIB";
}