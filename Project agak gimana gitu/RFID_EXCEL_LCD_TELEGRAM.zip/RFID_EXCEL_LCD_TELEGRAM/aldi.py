import serial
import openpyxl
from datetime import datetime

# Inisialisasi komunikasi Serial (sesuaikan COM port Arduino)
ser = serial.Serial('COM7', 9600)  

# Load atau buat file Excel baru
try:
    workbook = openpyxl.load_workbook("data_absensi.xlsx")
except FileNotFoundError:
    workbook = openpyxl.Workbook()
    sheet1 = workbook.active
    sheet1.title = "Database RFID"
    sheet1.append(["UID", "Nama"])  # Header Sheet 1
    sheet2 = workbook.create_sheet("Absensi")
    sheet2.append(["UID", "Nama", "Timestamp"])  # Header Sheet 2
    workbook.save("data_absensi.xlsx")

# Buka Sheet
sheet1 = workbook["Database RFID"]
sheet2 = workbook["Absensi"]

def cari_nama(uid):
    for row in sheet1.iter_rows(min_row=2, values_only=True):
        if str(row[0]).strip() == str(uid).strip():
            return row[1]  # Return nama sesuai UID
    return None  # Kembalikan None jika tidak ditemukan

print("Program Pengecekan RFID Siap...")

try:
    while True:
        if ser.in_waiting > 0:
            rfid_uid = ser.readline().decode('utf-8').strip()
            nama = cari_nama(rfid_uid)

            if nama:
                # Tambahkan data ke Sheet Absensi
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                sheet2.append([rfid_uid, nama, timestamp])
                workbook.save("data_absensi.xlsx")

                print(f"RFID: {rfid_uid}, Nama: {nama}, Waktu: {timestamp}")
                ser.write(nama.encode())  # Kirim nama ke Arduino

except KeyboardInterrupt:
    print("Program dihentikan.")
    ser.close()
    workbook.save("data_absensi.xlsx")